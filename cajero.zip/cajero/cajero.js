$(document).ready(function(){
    var contador_intentos = 0;
    $("#btn_retiro_con_tarjeta").click(function(){
        $("#div_inicial").hide();
        $("#div_retiro_con_tarjeta").show();
    });

    $("#btn_retiro_sin_tarjeta").click(function(){
        $("#div_inicial").hide();
        $("#div_retiro_sin_tarjeta").show();
    });

    $("#btn_retiro_nequi").click(function(){
        $("#div_inicial").hide();
        $("#div_retiro_nequi").show();
    });

    $("#btn_ahorro_a_la_mano").click(function(){
        $("#div_inicial").hide();
        $("#div_retiro_ahorro_a_la_mano").show();
    });

    $("#btn_ingresar_retiro_con_tarjeta").click(function(){
        var password_retiro_con_tarjeta = $("#password_retiro_con_tarjeta").val();

        if (password_retiro_con_tarjeta == "1193034236")
        {
            $("#div_retiro_con_tarjeta").hide();
            $("#div_seleccionar_cantidad").show();
        }
        else
        {
            contador_intentos++;
            
            if (contador_intentos == 3)
            {
                $("#div_retiro_con_tarjeta").hide();
                $("#div_bloqueo").show();
            }
        }

        $("#password_retiro_con_tarjeta").val('');
    });

    $("#btn_ingresar_retiro_sin_tarjeta").click(function(){
        var password_retiro_sin_tarjeta = $("#password_retiro_sin_tarjeta").val();

        if (password_retiro_sin_tarjeta == "1193034236")
        {
            $("#div_retiro_sin_tarjeta").hide();
            $("#div_seleccionar_cantidad").show();
        }
        else
        {
            contador_intentos++;
            
            if (contador_intentos == 3)
            {
                $("#div_retiro_sin_tarjeta").hide();
                $("#div_bloqueo").show();
            }
        }

        $("#password_retiro_sin_tarjeta").val('');
    });

    $("#btn_ingresar_retiro_nequi").click(function(){
        var password_retiro_nequi = $("#password_retiro_nequi").val();

        if (password_retiro_nequi == "1193034236")
        {
            $("#div_retiro_nequi").hide();
            $("#div_seleccionar_cantidad").show();
        }
        else
        {
            contador_intentos++;
            
            if (contador_intentos == 3)
            {
                $("#div_retiro_nequi").hide();
                $("#div_bloqueo").show();
            }
        }

        $("#password_retiro_nequi").val('');
    });

    $("#btn_ingresar_ahorro_a_la_mano").click(function(){
        var password_retiro_ahorro_a_la_mano = $("#password_retiro_ahorro_a_la_mano").val();

        if (password_retiro_ahorro_a_la_mano == "1193034236")
        {
            $("#div_retiro_ahorro_a_la_mano").hide();
            $("#div_seleccionar_cantidad").show();
        }
        else
        {
            contador_intentos++;
            
            if (contador_intentos == 3)
            {
                $("#div_retiro_ahorro_a_la_mano").hide();
                $("#div_bloqueo").show();
            }
        }

        $("#password_retiro_ahorro_a_la_mano").val('');
    });

    $("#btn_volver").click(function(){
        $("#div_seleccionar_cantidad").hide();
        $("#div_inicial").show();
        contador_intentos = 0;
    });

    $("#btn_retirar").click(function(){
        $("#div_seleccionar_cantidad").hide();
        $("#div_terminar").show();
    });

    $("#btn_regresar").click(function(){
        $("#div_bloqueo").hide();
        $("#div_inicial").show();
    });

    $("#btn_terminar").click(function(){
        $("#div_terminar").hide();
        $("#div_inicial").show();
        contador_intentos = 0;
    });
});